package com.example.jobtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    /* @BindView(R.id.home)
     ImageView homeIcon;
     @BindView(R.id.search)
     ImageView searchIcon;
     @BindView(R.id.profile)
     ImageView profileIcon;
     @BindView(R.id.cup)
     ImageView cupIcon;
 */
    ImageView home;
    ImageView search;
    ImageView profile;
    ImageView cup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ButterKnife.bind(this);
        home = findViewById(R.id.home);
        search = findViewById(R.id.home);
        profile = findViewById(R.id.home);
        cup = findViewById(R.id.home);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                home.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));
                search.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));
                home.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));
                home.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));

            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                search.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));

            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                profile.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));

            }
        });
        cup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cup.setImageResource(getResources().getIdentifier("home_bottom_icon", "drawable", getPackageName()));

            }
        });
    }

}